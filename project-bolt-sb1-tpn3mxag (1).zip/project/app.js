// Importar módulo de banco de dados
const db = require('./db.js');

// Funções de manipulação de tarefas
async function addTask(event) {
    event.preventDefault();

    const task = {
        id: generateId(),
        title: document.getElementById('title').value,
        description: document.getElementById('description').value,
        priority: document.getElementById('priority').value,
        status: document.getElementById('status').value
    };

    try {
        await db.createTask(task);
        await renderTasks();
        event.target.reset();
    } catch (error) {
        console.error('Erro ao adicionar tarefa:', error);
        alert('Erro ao adicionar tarefa. Por favor, tente novamente.');
    }
}

async function deleteTask(taskId) {
    try {
        await db.deleteTask(taskId);
        await renderTasks();
    } catch (error) {
        console.error('Erro ao deletar tarefa:', error);
        alert('Erro ao deletar tarefa. Por favor, tente novamente.');
    }
}

async function updateTaskStatus(taskId, newStatus) {
    try {
        await db.updateTaskStatus(taskId, newStatus);
    } catch (error) {
        console.error('Erro ao atualizar status da tarefa:', error);
        alert('Erro ao atualizar status. Por favor, tente novamente.');
    }
}

async function renderTasks() {
    const tasksContainer = document.getElementById('tasksContainer');
    tasksContainer.innerHTML = '';

    try {
        const tasks = await db.getAllTasks();
        tasks.forEach(task => {
            tasksContainer.appendChild(createTaskElement(task));
        });
        
        // Atualizar ícones do Lucide
        lucide.createIcons();
    } catch (error) {
        console.error('Erro ao carregar tarefas:', error);
        tasksContainer.innerHTML = '<p class="error">Erro ao carregar tarefas. Por favor, recarregue a página.</p>';
    }
}

// Função auxiliar que permanece igual
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

function createTaskElement(task) {
    const taskElement = document.createElement('div');
    taskElement.className = 'task-card';
    taskElement.innerHTML = `
        <div class="task-header">
            <h3 class="task-title">${task.title}</h3>
            <span class="task-priority priority-${task.priority}">${
                task.priority === 'low' ? 'Baixa' :
                task.priority === 'medium' ? 'Média' : 'Alta'
            }</span>
        </div>
        <p class="task-description">${task.description}</p>
        <div class="task-footer">
            <select class="task-status" data-id="${task.id}">
                <option value="pending" ${task.status === 'pending' ? 'selected' : ''}>Pendente</option>
                <option value="in-progress" ${task.status === 'in-progress' ? 'selected' : ''}>Em Progresso</option>
                <option value="completed" ${task.status === 'completed' ? 'selected' : ''}>Concluída</option>
            </select>
            <div class="task-actions">
                <button class="btn-icon delete-task" data-id="${task.id}">
                    <i data-lucide="trash-2"></i>
                </button>
            </div>
        </div>
    `;

    // Configurar event listeners
    const deleteBtn = taskElement.querySelector('.delete-task');
    deleteBtn.addEventListener('click', () => deleteTask(task.id));

    const statusSelect = taskElement.querySelector('.task-status');
    statusSelect.addEventListener('change', (e) => updateTaskStatus(task.id, e.target.value));

    return taskElement;
}

// Event Listeners
document.getElementById('taskForm').addEventListener('submit', addTask);

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
    renderTasks();
});