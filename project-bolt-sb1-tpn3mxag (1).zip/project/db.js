const mysql = require('mysql2/promise');

// Configuração da conexão com o banco de dados
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'sua_senha',
    database: 'task_manager',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// Funções de acesso ao banco de dados
async function getAllTasks() {
    try {
        const [rows] = await pool.query('SELECT * FROM tasks ORDER BY created_at DESC');
        return rows;
    } catch (error) {
        console.error('Erro ao buscar tarefas:', error);
        throw error;
    }
}

async function createTask(task) {
    try {
        const [result] = await pool.query(
            'INSERT INTO tasks (id, title, description, priority, status) VALUES (?, ?, ?, ?, ?)',
            [task.id, task.title, task.description, task.priority, task.status]
        );
        return result;
    } catch (error) {
        console.error('Erro ao criar tarefa:', error);
        throw error;
    }
}

async function updateTaskStatus(taskId, status) {
    try {
        const [result] = await pool.query(
            'UPDATE tasks SET status = ? WHERE id = ?',
            [status, taskId]
        );
        return result;
    } catch (error) {
        console.error('Erro ao atualizar status da tarefa:', error);
        throw error;
    }
}

async function deleteTask(taskId) {
    try {
        const [result] = await pool.query('DELETE FROM tasks WHERE id = ?', [taskId]);
        return result;
    } catch (error) {
        console.error('Erro ao deletar tarefa:', error);
        throw error;
    }
}

module.exports = {
    getAllTasks,
    createTask,
    updateTaskStatus,
    deleteTask
};