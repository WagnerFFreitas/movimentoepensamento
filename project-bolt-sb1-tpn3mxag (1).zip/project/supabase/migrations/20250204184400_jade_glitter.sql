/*
  # Task Manager Database Schema

  1. New Tables
    - `tasks`
      - `id` (varchar, primary key)
      - `title` (varchar)
      - `description` (text)
      - `priority` (enum: low, medium, high)
      - `status` (enum: pending, in-progress, completed)
      - `created_at` (timestamp)
*/

CREATE DATABASE IF NOT EXISTS task_manager;
USE task_manager;

CREATE TABLE IF NOT EXISTS tasks (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    priority ENUM('low', 'medium', 'high') NOT NULL DEFAULT 'medium',
    status ENUM('pending', 'in-progress', 'completed') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);