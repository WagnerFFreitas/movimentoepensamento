// Gerenciamento de estado
let tasks = JSON.parse(localStorage.getItem('tasks')) || [];

// Funções auxiliares
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

function saveToLocalStorage() {
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

function createTaskElement(task) {
    const taskElement = document.createElement('div');
    taskElement.className = 'task-card';
    taskElement.innerHTML = `
        <div class="task-header">
            <h3 class="task-title">${task.title}</h3>
            <span class="task-priority priority-${task.priority}">${
                task.priority === 'low' ? 'Baixa' :
                task.priority === 'medium' ? 'Média' : 'Alta'
            }</span>
        </div>
        <p class="task-description">${task.description}</p>
        <div class="task-footer">
            <select class="task-status" data-id="${task.id}">
                <option value="pending" ${task.status === 'pending' ? 'selected' : ''}>Pendente</option>
                <option value="in-progress" ${task.status === 'in-progress' ? 'selected' : ''}>Em Progresso</option>
                <option value="completed" ${task.status === 'completed' ? 'selected' : ''}>Concluída</option>
            </select>
            <div class="task-actions">
                <button class="btn-icon delete-task" data-id="${task.id}">
                    <i data-lucide="trash-2"></i>
                </button>
            </div>
        </div>
    `;

    // Configurar event listeners
    const deleteBtn = taskElement.querySelector('.delete-task');
    deleteBtn.addEventListener('click', () => deleteTask(task.id));

    const statusSelect = taskElement.querySelector('.task-status');
    statusSelect.addEventListener('change', (e) => updateTaskStatus(task.id, e.target.value));

    return taskElement;
}

// Funções de manipulação de tarefas
function addTask(event) {
    event.preventDefault();

    const task = {
        id: generateId(),
        title: document.getElementById('title').value,
        description: document.getElementById('description').value,
        priority: document.getElementById('priority').value,
        status: document.getElementById('status').value,
        createdAt: new Date()
    };

    tasks.push(task);
    saveToLocalStorage();
    renderTasks();
    event.target.reset();
}

function deleteTask(taskId) {
    tasks = tasks.filter(task => task.id !== taskId);
    saveToLocalStorage();
    renderTasks();
}

function updateTaskStatus(taskId, newStatus) {
    const task = tasks.find(task => task.id === taskId);
    if (task) {
        task.status = newStatus;
        saveToLocalStorage();
    }
}

function renderTasks() {
    const tasksContainer = document.getElementById('tasksContainer');
    tasksContainer.innerHTML = '';

    tasks.forEach(task => {
        tasksContainer.appendChild(createTaskElement(task));
    });

    // Atualizar ícones do Lucide
    lucide.createIcons();
}

// Event Listeners
document.getElementById('taskForm').addEventListener('submit', addTask);

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
    renderTasks();
});